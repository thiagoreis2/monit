<?php
    
    error_reporting(E_ALL);
    ini_set('display_errors', 'On');
    
    require './vendor/autoload.php';
    
    use Dompdf\Dompdf;

    require 'asks.php';
    
    if(!isset($_POST['btnPdf'])) die;

    $form = $_POST['btnPdf'];

    foreach($asks[$form] as $key => $ask):
        
        $inputAsk = 'uni'.$form.'ask'.$key;
        $obsAsk = 'uni'.$form.'obs'.$key;

        foreach($_POST as $var => $input){
           if($var == $inputAsk){
                $asks[$form][$key]['answer'] = $input;
           }

           if($var == $obsAsk){
                $asks[$form][$key]['obs'] = $input;
                break;
           }
        }
    endforeach;


    $titles = [
        'Monitoramento da Aprendizagem - Volume 2: 3 a 4 anos – Unidades 1 e 2 / 1º Bimestre ',
        'Monitoramento da Aprendizagem - Volume 2: 3 a 4 anos – Unidades 3 e 4 / 2º Bimestre',
        'Monitoramento da Aprendizagem - Volume 2: 3 a 4 anos – Unidades 5 e 6 / 3º Bimestre',
        'Monitoramento da Aprendizagem - Volume 2: 3 a 4 anos – Unidades 7 e 8 / 4º Bimestre'
    ];
    
    $data = "<!DOCTYPE html>";
    $data .= "<html lang='pt-br'>";
    $data .= "<head>";
    $data .= "<meta charset='UTF-8'>";
    $data .= "<link rel='stylesheet' href='https://askia.info/monitoramento-de-alunos/assets/css/normalize.css'";
    $data .= "<title></title>";
    $data .= "<style>font-size: 0.8em;</style>";
    $data .= "</head>";
    $data .= "<body>";
    $data .= "<main class='container'><br><br>";
    $data .= "<h2 class='text u-align-left'>".$titles[$form]."</h2><br>";
    $data .= "<h2 class='text u-align-center'>Professor ".$_POST['teacher']."</h2><br>";
    $data .= "<h2 class='text u-align-center'>Aluno ".$_POST['user']."</h2>";
    
    $data .= "
    <table class='u-table primary-color'>
        <thead class='u-table-header'>
            <tr>
                <td class='tiny-text'>HABILIDADES / DESTREZAS</td>
                <td class='tiny-text'style='width: 70px; letter-spacing: 5px;'>ABC</td>
                <td class='tiny-text'>OBSERVAÇÃO</td>
            </tr>
        </thead>
        <tbody class='u-table-body'>";

    foreach($asks[$form] as $ask):
        $data .= '<tr>';
        $data .= '<td>'.$ask['ask'].'</td>';
        $data .= '<td>';
        $data .= $ask['answer'] == "a" ? "<input type='radio' name='' checked>" : "<input type='radio' name=''>";
        $data .= $ask['answer'] == "b" ? "<input type='radio' name='' checked>" : "<input type='radio' name=''>";
        $data .= $ask['answer'] == "c" ? "<input type='radio' name='' checked>" : "<input type='radio' name=''>";
        $data .= '</td>';
        $data .= '<td>'.$ask['obs'].'</td>';
        $data .= '</tr>';
    endforeach;


    $data .= "</tbody>";
    $data .= "</table>";
    $data .= "</main>";
    $data .= "</body>";

    $dompdf = new Dompdf(['enable_remote' => true]);

    $dompdf->loadHtml($data);

    $dompdf->setPaper('A4', 'portrait');
    $dompdf->set_option('enable_remote', TRUE);
    $dompdf->set_option('enable_css_float', TRUE);
    $dompdf->set_option('enable_html5_parser', FALSE);
    $dompdf->render();

    // Gerar o PDF
    $filename = str_replace(' ', '_', strtolower($_POST['user']));
    $filename = 'monitoramento_'.$filename.'.pdf';
    $dompdf->stream($filename);

    $output = $dompdf->output();
    
    $dir = 'generated/';

    if(!is_dir($dir)):
        mkdir($dir);
    endif;
    
    $file = str_replace(' ', '_', strtolower($_POST['user']));
    file_put_contents($dir.$file.'_'.date('Y-m-d').'.pdf', $output);