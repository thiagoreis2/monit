<?php

    $asks = [
        0 => [
            array(
                'ask' => 'Ouve e participa atentamente das atividades orais, respondendo a perguntas simples feitas pelo interlocutor.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Percebe a semelhança entre partes sonoras de palavras quando as ouve, identificando e compreendendo conceito de rima, por exemplo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Responde oralmente com autonomia perguntas referentes ao textos lidos/ouvidos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Entende narrativas mais elaboradas, segue e compreende histórias mais longas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Reconhece semelhança sonora em palavras iniciadas com o mesmo som.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Identifica oralmente elementos, como personagens principais, entre outros eventos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Reconhece os números 1 e 2, associando-os às quantidade correspondentes.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Entende a ordem dos números até aqui apresentados.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Distingue corretamente a quantidade que representa a idade em que se encontra.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Relaciona corretamente conceitos, como: em cima/embaixo, em frente/atrás, ao lado.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Percebe semelhanças e diferenças entre formas e figuras parecidas, sejam elas aos pares, sombras ou partes específicas de um todo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Diferencia e utiliza das cores com autonomia na realização das atividades.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Faz uso de gestos e movimentos para representar partes do corpo durante atividades em sala de aula, músicas e atividades físicas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Apresenta desenvoltura na coordenação entre o movimento das mãos e a visão, como pegar objetos pequenos, encaixar peças de quebra-cabeça e desenhar.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Demonstra aprimoramento da estabilidade corporal, como: flexionar, equilibrar, estender, girar, etc.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Participa de atividades físicas que incentivam a criatividade e a expressão.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Manipula com facilidade diferentes recursos materiais na confecção de desenhos, brinquedos ou durante a realização das atividades práticas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Demonstra aprimoramento das habilidades motoras, incluindo coordenação e controle durante a realização das diferentes atividades.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Reconhece a si próprio como um ser pensante capaz de observar e compreender o mundo à sua volta.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Utiliza-se da convivência com os outros colegas reforçando princípios básicos de amizade.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Desenvolve atitudes de amizades simples e interação positiva com pares.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Faz uso de palavras simples para resolver conflitos de forma construtiva.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Participa em brincadeiras de grupo e interações com outras crianças.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Identifica e nomeia emoções próprias, como tristeza, alegria, medo, dor, etc.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Utiliza-se de estratégias lógicas pertinentes a idade em que se encontra para superar obstáculos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Compreende a ordem dos eventos em seqüências temporais, como antes, durante e depois.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Controla impulsos simples, como esperar a sua vez durante jogos em grupo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Organiza os materiais adequadamente de acordo com a atividade em que está executando.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Recorda-se de eventos recentes ou atividades realizadas há pouco tempo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Segue regras simples estabelecidas em atividades, jogos e brincadeiras.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            )
        ],
        1 => [
            array(
                'ask' => 'Manipula e folheia corretamente cadernos livros e revistas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Usa palavras simples do cotidiano para se expressar, e comunicar-se de forma compreensível.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Aponta e reconhece imagens/figuras de acordo com o texto ouvido ou solicitado pelo professor.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Ouve, reconhece e diferencia elementos de um mesmo campo semântico, como as frutas, por exemplo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Reconhece e identifica as palavras e seus significados percebendo suas partes sonoras e seus significados através de figuras.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Apresenta desenvolvimento da habilidade de formar oralmente frases completas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literancia'
            ),
            array(
                'ask' => 'Reconhece os números de 1 a 4, associando-os as quantidades correspondentes.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Relaciona um número (valor) com o número apropriado de objetos (quantidade).',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Realiza de forma satisfatória a contagem de pequenas quantidades.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Explora com autonomia conceitos de medida, como "maior" e "menor", em objetos do ambiente.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Identifica e reconhece as formas geométricas básicas (triângulo, retângulo, quadrado, círculo).',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Identifica, nomeia e relaciona cores em objetos específicos. Ex: maçã/vermelha, sol/amarelo, grama/verde, etc.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Apresenta maior destreza nas mãos e nos dedos durante a realização de atividades como, pintura, manipulação de objetos, recorte e colagem, entre outros.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Realiza movimentos de pega, pinça, encaixe, durante a realização das atividades.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Concretiza atividades que envolvem coordenação motora ampla, como correr, saltar, subir escadas, pular com um pé só e chutar uma bola.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Traça, segue, cobre linhas pontilhadas/tracejadas ou formas específicas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Pinta com certa autonomia, compreendendo e respeitando os contornos dos desenhos e suas formas específicas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Desenvolve atividades que exigem o uso de uma parte específica ou apenas um lado do corpo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Compartilha objetos pessoais e da sala de aula com os colegas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Demonstra autonomia na escolha de objetos ou materiais específicos na realização das atividades, jogos e brincadeiras.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Utiliza os órgãos dos sentidos para expressar seus sentimentos, suas escolhas e preferências pessoais, através do gosto, cheiro, contato, entre outros.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Compreende que cada parte do corpo é responsável por uma ou mais funções.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Interage de forma autônoma com os colegas e o professor em sala de aula.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Realiza atividades individuais e coletivas com interesse.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Faz o uso de estratégias simples para lidar com emoções intensas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Percebe um padrão específico em atividades e encontra forma de solucioná-los.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Mantém atenção sustentada durante a realização da atividade. ',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Organiza seus pensamentos, ideias e utiliza-os como estratégias efetivas para desenvolver as atividades propostas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Demonstra capacidade de tomar decisões simples em situações cotidianas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Segue regras estabelecidas em atividades que envolvem atitudes individual e coletiva.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
                                                
                                        
        ],
        2 => [
            array(
                'ask' => 'Demonstra compreender a relação entre elementos sonoros das palavras (consciência fonológica), incluindo a identificação de rimas e outras unidades sonoras.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Lembra-se da ordem de fatos e acontecimentos ouvidos/citados.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Canta uma música ou recita um pequeno poema, sozinho ou na companhia do professor e dos colegas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Compreende em um diálogo a fala dos colegas e do professor.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Apresenta consciência de sílabas, identificando partes sonoras do nome, ou outros elementos, quantificando e manipulando-as oralmente.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Responde ou busca identificar a resposta correta, ao ouvir uma charada, quadrinha ou adivinha, por exemplo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Reconhece os números de 1 a 6, associando-os as quantidades correspondentes.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numerancia'
            ),
            array(
                'ask' => 'Compreende a posição relativa dos números já conhecidos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numerancia'
            ),
            array(
                'ask' => 'Utiliza-se das formas em atividades de encaixe, segmentação ou comparação.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numerancia'
            ),
            array(
                'ask' => 'Classifica e agrupa objetos com base em atributos numéricos, como tamanho ou cor.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numerancia'
            ),
            array(
                'ask' => 'Reconhece elementos específicos do dia e da noite, percebendo esses eventos através da passagem do tempo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numerancia'
            ),
            array(
                'ask' => 'Percebe e encontra diferenças e semelhanças em figuras ou cenas parecidas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numerancia'
            ),
            array(
                'ask' => 'Canta, gesticula e realiza movimentos pertinentes as atividades, jogos e brincadeiras desenvolvidas dentro e fora da sala de aula.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Desenha figuras simples com maior proximidade com a realidade física do objeto/elemento. Ex: sol, fruta, pessoa.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Manipula diferentes materiais na realização de atividades, como: recota, pintar, rasgar, amassar, dobrar, entre outros.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Demonstra facilidade em realizar movimentos inesperados ou desconhecidos em atividades, jogos e brincadeiras novas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Coordena e manuseia com precisão diferentes objetos e materiais.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Apresenta aprimoramento das habilidades motoras finas, incluindo desenhar formas mais precisas, recortar com tesoura e manipular objetos pequenos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Reconhece-se como individuo único com seus gostos, vontades e interesses próprios.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Faz uso adequado das emoções/expressões de acordo com a situação em que se encontra.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Interage de forma esperada para idade, com os colegas e o professor. ',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Comunica-se e expressa-se de acordo com suas necessidades e interesses.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Demonstra interesse ao ver as atividades e avanços dos colegas da sala de aula.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Faz uso adequado das emoções, se fazendo entender e solicita ajuda quando necessário.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Demonstra capacidade de solucionar atividades que envolvem o raciocínio lógico e atenção específica, como: quebra-cabeça, recorte e colagem, por exemplo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Presta atenção e repete padrões específicos apresentados pelo professor em atividades, jogos e brincadeiras.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Raciocina de forma autônoma em atividade que requer atenção e observação de certos padrões, como cores, formas, direção, posição, entre outros.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Lembra-se e faz uso adequado de informações e instruções previamentes dadas pelo professor. ',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Demonstra facilidade em mudar de estratégia na realização de uma atividade.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Planeja antecipadamente uma rota/caminho para resolver um problema ou atividade específica com autonomia. ',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            )
        ],
        3 => [
            array(
                'ask' => 'Acompanha utilizando com o dedo ou outro manipulativo a direção das palavras, frases e em pequenos textos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Demonstra interesse em ouvir textos, histórias, poemas, músicas, entre outros, no processo de desenvolvimento da leitura.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Ouve e responde com autonomia questões orais simples feitas pelo professor.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Experimenta através de traçados utilizando lápis ou giz, incluindo tentativas de desenhar letras ou números.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Reconhece os diferentes sons da fala pertinentes as habilidades de consciência fonológica, incluindo a identificação de rimas, aliterações e partes sonoras em palavras.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Comunica-se de forma satisfatória, fazendo-se entender.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Literacia'
            ),
            array(
                'ask' => 'Reconhece os números de 1 a 9 e o número 0, associando-os as suas quantidades correspondentes.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Faz uso de termos numéricos em conversas cotidianas, como "mais", "menos", "igual a", "maior que" e "menor que".',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Identifica cores, formas em uma cena ou ambiente real, percebendo suas relações.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Compara tamanhos e comprimentos, através de vivências e da observação direta.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Percebe a ordem dos eventos em sequências temporais, como antes, durante e depois.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Numeracia'
            ),
            array(
                'ask' => 'Apresenta avanço na precisão e no controle dos movimentos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Faz atividades de desenho e pintura observando o modelo e replicando-o respeitando as linhas, formas, traçados e cores.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Realiza movimentos, como bater palmas, girar, agachar, dançar, entre outros de acordo com a idade em que se encontra.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Desenvolve atividades de recorte, colagem e dobradura de forma satisfatória.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Demonstra coordenação aprimorada em atividades físicas.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Exibe aumento da força muscular, permitindo a participação em atividades que exigem esforço físico, como: levantar, arremessar, puxar, empurrar, dobrar, esticar.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Psicomotricidade'
            ),
            array(
                'ask' => 'Entende-se como ser único, percebendo as semelhanças e diferenças físicas de cada indivíduo.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Reconhece e identifica suas características físicas específicas, como cor dos olhos, cabelo, formato, altura, entre outros.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Percebe-se como parte de uma família que é composta de diferentes membros.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Respeita as diferenças entre os pares e demonstra atitudes de empatia e solidariedade.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Realiza atividades e demonstra expressões diversas ao ouvir diferentes músicas e/ou escutar o toque de instrumentos diversos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Demonstra interesse por instrumentos e músicas e apresenta interesse ao ouvi-los.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Socioemocional'
            ),
            array(
                'ask' => 'Percebe padrões específicos como marcas em animais, cores específicas e demonstra compreender essas particularidades.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Mantém o foco em uma atividade por períodos mais longos.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Participa ativamente de atividades que requerem atenção contínua.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Concentra-se ao realizar atividades que envolvem a confecção de objetos específicos, como um instrumento musical feito a partir de materiais recicláveis.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Demonstra capacidade de improvisação durante a execução de um projeto, jogo, brincadeira ou uma atividade.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            ),
            array(
                'ask' => 'Utiliza-se de estratégias lógicas para superar obstáculos simples durante a realização das atividades.',
                'answer' => '',
                'obs' => '',
                'cat' => 'Funções Executivas'
            )
        ]
    ];
    
