<?php require 'app/asks.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form 2</title>
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/normalize.css">
</head>
<body>
    <main>
        <div class="row">
            <div class="container">
                <br>
                <br>
                <section>
                    <form method="post" action="app/print.php">
                    <div class="header-ask">
                        <h2 class="text">Monitoramento da Aprendizagem - Volume 2: 3 a 4 anos – Unidades 3 e 4 / 2º Bimestre </h2>
                    </div>
                    <br>
                    <div class="" style="width:100%; padding: 10px; border: 1px solid #ccc; background: #f1f1f1; display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <label for="" class="u-label-input tiny-text ">Professor</label>
                        <input class="" name="teacher">
                        <label for="" class="u-label-input tiny-text ">Aluno</label>
                        <input class="" name="user">
                    </div>
                    <br>
                    <div>
                        <p class="u-alert tiny-text text-strong" style="background: #f2f2f2; border: 1px solid #ccc;"> REALIZAÇÃO: A = realiza a atividade;     B = faz com ajuda;     C = tenta fazer; </p>
                    </div>

                    <table class="u-table primary-color">
                        <thead class="u-table-header">
                            <tr>
                                <td>HABILIDADES/DESTREZAS</td>
                                <td style="width: 80px">A B C</td>
                                <td>OBSERVAÇÃO</td>
                            </tr>
                        </thead>
                        <tbody class="u-table-body">
                            <?php foreach($asks[1] as $i => $ask):?>
                            <?php if(!isset($cat)):?>
                                <tr>
                                    <?php $cat = $ask['cat']?>
                                    <td class="u-align-left text-strong"><?=$cat?></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endif;?>
                            <?php if($cat !== $ask['cat']): $cat = $ask['cat']; ?>
                                <tr>
                                    <td class="u-align-left text-strong"><?=$cat?></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endif;?>
                            <tr>
                                <td class="u-align-left"><?=$ask['ask']?></td>
                                <td>
                                    <input type="radio" name="uni1ask<?=$i?>" value="a">
                                    <input type="radio"  name="uni1ask<?=$i?>" value="b">
                                    <input type="radio"  name="uni1ask<?=$i?>" value="c">
                                </td>
                                <td style="padding: none;"><textarea name="uni1obs<?=$i?>" style="resize:none; width: 100%; border: none; background: #f1f1f1;" value=""></textarea></td>
                            </tr>
                            <?php endforeach; ?>

                        </tbody>
                    </table>
                    <br>
                    <button class="btn btn-none h-float--right" style="background: #f1f1f1; color: #000; border: 1px solid;" name="btnPdf" value="1">Gerar Pdf</button>
                    <br>
                    <br>
                    <br>
                    </form>
                </section>
            </div>
        </div>   
    </main>
</body>
</html>